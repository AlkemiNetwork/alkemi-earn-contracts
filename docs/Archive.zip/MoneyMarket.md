# The MoneyMarket Contract (MoneyMarket.sol)

View Source: [contracts/MoneyMarket.sol](../contracts/MoneyMarket.sol)

**↗ Extends: [Exponential](Exponential.md), [SafeToken](SafeToken.md)**

**MoneyMarket**

The MoneyMarket Contract is the core contract governing
all accounts

## Structs

### Balance

```js
struct Balance {
 uint256 principal,
 uint256 interestIndex
}
```

### Market

```js
struct Market {
 bool isSupported,
 uint256 blockNumber,
 contract InterestRateModel interestRateModel,
 uint256 totalSupply,
 uint256 supplyRateMantissa,
 uint256 supplyIndex,
 uint256 totalBorrows,
 uint256 borrowRateMantissa,
 uint256 borrowIndex
}
```

### SupplyLocalVars

```js
struct SupplyLocalVars {
 uint256 startingBalance,
 uint256 newSupplyIndex,
 uint256 userSupplyCurrent,
 uint256 userSupplyUpdated,
 uint256 newTotalSupply,
 uint256 currentCash,
 uint256 updatedCash,
 uint256 newSupplyRateMantissa,
 uint256 newBorrowIndex,
 uint256 newBorrowRateMantissa
}
```

### WithdrawLocalVars

```js
struct WithdrawLocalVars {
 uint256 withdrawAmount,
 uint256 startingBalance,
 uint256 newSupplyIndex,
 uint256 userSupplyCurrent,
 uint256 userSupplyUpdated,
 uint256 newTotalSupply,
 uint256 currentCash,
 uint256 updatedCash,
 uint256 newSupplyRateMantissa,
 uint256 newBorrowIndex,
 uint256 newBorrowRateMantissa,
 struct Exponential.Exp accountLiquidity,
 struct Exponential.Exp accountShortfall,
 struct Exponential.Exp ethValueOfWithdrawal,
 uint256 withdrawCapacity
}
```

### AccountValueLocalVars

```js
struct AccountValueLocalVars {
 address assetAddress,
 uint256 collateralMarketsLength,
 uint256 newSupplyIndex,
 uint256 userSupplyCurrent,
 struct Exponential.Exp supplyTotalValue,
 struct Exponential.Exp sumSupplies,
 uint256 newBorrowIndex,
 uint256 userBorrowCurrent,
 struct Exponential.Exp borrowTotalValue,
 struct Exponential.Exp sumBorrows
}
```

### PayBorrowLocalVars

```js
struct PayBorrowLocalVars {
 uint256 newBorrowIndex,
 uint256 userBorrowCurrent,
 uint256 repayAmount,
 uint256 userBorrowUpdated,
 uint256 newTotalBorrows,
 uint256 currentCash,
 uint256 updatedCash,
 uint256 newSupplyIndex,
 uint256 newSupplyRateMantissa,
 uint256 newBorrowRateMantissa,
 uint256 startingBalance
}
```

### BorrowLocalVars

```js
struct BorrowLocalVars {
 uint256 newBorrowIndex,
 uint256 userBorrowCurrent,
 uint256 borrowAmountWithFee,
 uint256 userBorrowUpdated,
 uint256 newTotalBorrows,
 uint256 currentCash,
 uint256 updatedCash,
 uint256 newSupplyIndex,
 uint256 newSupplyRateMantissa,
 uint256 newBorrowRateMantissa,
 uint256 startingBalance,
 struct Exponential.Exp accountLiquidity,
 struct Exponential.Exp accountShortfall,
 struct Exponential.Exp ethValueOfBorrowAmountWithFee
}
```

### LiquidateLocalVars

```js
struct LiquidateLocalVars {
 address targetAccount,
 address assetBorrow,
 address liquidator,
 address assetCollateral,
 uint256 newBorrowIndex_UnderwaterAsset,
 uint256 newSupplyIndex_UnderwaterAsset,
 uint256 newBorrowIndex_CollateralAsset,
 uint256 newSupplyIndex_CollateralAsset,
 uint256 currentBorrowBalance_TargetUnderwaterAsset,
 uint256 updatedBorrowBalance_TargetUnderwaterAsset,
 uint256 newTotalBorrows_ProtocolUnderwaterAsset,
 uint256 startingBorrowBalance_TargetUnderwaterAsset,
 uint256 startingSupplyBalance_TargetCollateralAsset,
 uint256 startingSupplyBalance_LiquidatorCollateralAsset,
 uint256 currentSupplyBalance_TargetCollateralAsset,
 uint256 updatedSupplyBalance_TargetCollateralAsset,
 uint256 currentSupplyBalance_LiquidatorCollateralAsset,
 uint256 updatedSupplyBalance_LiquidatorCollateralAsset,
 uint256 newTotalSupply_ProtocolCollateralAsset,
 uint256 currentCash_ProtocolUnderwaterAsset,
 uint256 updatedCash_ProtocolUnderwaterAsset,
 uint256 newSupplyRateMantissa_ProtocolUnderwaterAsset,
 uint256 newBorrowRateMantissa_ProtocolUnderwaterAsset,
 uint256 discountedRepayToEvenAmount,
 uint256 discountedBorrowDenominatedCollateral,
 uint256 maxCloseableBorrowAmount_TargetUnderwaterAsset,
 uint256 closeBorrowAmount_TargetUnderwaterAsset,
 uint256 seizeSupplyAmount_TargetCollateralAsset,
 struct Exponential.Exp collateralPrice,
 struct Exponential.Exp underwaterAssetPrice
}
```

## Contract Members

**Constants & Variables**

```js
//internal members
uint256 internal constant initialInterestIndex;
uint256 internal constant defaultOriginationFee;
uint256 internal constant minimumCollateralRatioMantissa;
uint256 internal constant maximumLiquidationDiscountMantissa;

//public members
address public pendingAdmin;
address public admin;
address public oracle;
mapping(address => mapping(address => struct MoneyMarket.Balance)) public supplyBalances;
mapping(address => mapping(address => struct MoneyMarket.Balance)) public borrowBalances;
mapping(address => struct MoneyMarket.Market) public markets;
address[] public collateralMarkets;
struct Exponential.Exp public collateralRatio;
struct Exponential.Exp public originationFee;
struct Exponential.Exp public liquidationDiscount;
bool public paused;

```

**Events**

```js
event SupplyReceived(address  account, address  asset, uint256  amount, uint256  startingBalance, uint256  newBalance);
event SupplyWithdrawn(address  account, address  asset, uint256  amount, uint256  startingBalance, uint256  newBalance);
event BorrowTaken(address  account, address  asset, uint256  amount, uint256  startingBalance, uint256  borrowAmountWithFee, uint256  newBalance);
event BorrowRepaid(address  account, address  asset, uint256  amount, uint256  startingBalance, uint256  newBalance);
event BorrowLiquidated(address  targetAccount, address  assetBorrow, uint256  borrowBalanceBefore, uint256  borrowBalanceAccumulated, uint256  amountRepaid, uint256  borrowBalanceAfter, address  liquidator, address  assetCollateral, uint256  collateralBalanceBefore, uint256  collateralBalanceAccumulated, uint256  amountSeized, uint256  collateralBalanceAfter);
event NewPendingAdmin(address  oldPendingAdmin, address  newPendingAdmin);
event NewAdmin(address  oldAdmin, address  newAdmin);
event NewOracle(address  oldOracle, address  newOracle);
event SupportedMarket(address  asset, address  interestRateModel);
event NewRiskParameters(uint256  oldCollateralRatioMantissa, uint256  newCollateralRatioMantissa, uint256  oldLiquidationDiscountMantissa, uint256  newLiquidationDiscountMantissa);
event NewOriginationFee(uint256  oldOriginationFeeMantissa, uint256  newOriginationFeeMantissa);
event SetMarketInterestRateModel(address  asset, address  interestRateModel);
event EquityWithdrawn(address  asset, uint256  equityAvailableBefore, uint256  amount, address  owner);
event SuspendedMarket(address  asset);
event SetPaused(bool  newState);
```

## Functions

- [()](#)
- [min(uint256 a, uint256 b)](#min)
- [getBlockNumber()](#getblocknumber)
- [addCollateralMarket(address asset)](#addcollateralmarket)
- [getCollateralMarketsLength()](#getcollateralmarketslength)
- [calculateInterestIndex(uint256 startingInterestIndex, uint256 interestRateMantissa, uint256 blockStart, uint256 blockEnd)](#calculateinterestindex)
- [calculateBalance(uint256 startingBalance, uint256 interestIndexStart, uint256 interestIndexEnd)](#calculatebalance)
- [getPriceForAssetAmount(address asset, uint256 assetAmount)](#getpriceforassetamount)
- [getPriceForAssetAmountMulCollatRatio(address asset, uint256 assetAmount)](#getpriceforassetamountmulcollatratio)
- [calculateBorrowAmountWithFee(uint256 borrowAmount)](#calculateborrowamountwithfee)
- [fetchAssetPrice(address asset)](#fetchassetprice)
- [assetPrices(address asset)](#assetprices)
- [getAssetAmountForValue(address asset, struct Exponential.Exp ethValue)](#getassetamountforvalue)
- [\_setPendingAdmin(address newPendingAdmin)](#_setpendingadmin)
- [\_acceptAdmin()](#_acceptadmin)
- [\_setOracle(address newOracle)](#_setoracle)
- [\_setPaused(bool requestedState)](#_setpaused)
- [getAccountLiquidity(address account)](#getaccountliquidity)
- [getSupplyBalance(address account, address asset)](#getsupplybalance)
- [getBorrowBalance(address account, address asset)](#getborrowbalance)
- [\_supportMarket(address asset, InterestRateModel interestRateModel)](#_supportmarket)
- [\_suspendMarket(address asset)](#_suspendmarket)
- [\_setRiskParameters(uint256 collateralRatioMantissa, uint256 liquidationDiscountMantissa)](#_setriskparameters)
- [\_setOriginationFee(uint256 originationFeeMantissa)](#_setoriginationfee)
- [\_setMarketInterestRateModel(address asset, InterestRateModel interestRateModel)](#_setmarketinterestratemodel)
- [\_withdrawEquity(address asset, uint256 amount)](#_withdrawequity)
- [supply(address asset, uint256 amount)](#supply)
- [withdraw(address asset, uint256 requestedAmount)](#withdraw)
- [calculateAccountLiquidity(address userAddress)](#calculateaccountliquidity)
- [calculateAccountValuesInternal(address userAddress)](#calculateaccountvaluesinternal)
- [calculateAccountValues(address userAddress)](#calculateaccountvalues)
- [repayBorrow(address asset, uint256 amount)](#repayborrow)
- [liquidateBorrow(address targetAccount, address assetBorrow, address assetCollateral, uint256 requestedAmountClose)](#liquidateborrow)
- [emitLiquidationEvent(struct MoneyMarket.LiquidateLocalVars localResults)](#emitliquidationevent)
- [calculateDiscountedRepayToEvenAmount(address targetAccount, struct Exponential.Exp underwaterAssetPrice)](#calculatediscountedrepaytoevenamount)
- [calculateDiscountedBorrowDenominatedCollateral(struct Exponential.Exp underwaterAssetPrice, struct Exponential.Exp collateralPrice, uint256 supplyCurrent_TargetCollateralAsset)](#calculatediscountedborrowdenominatedcollateral)
- [calculateAmountSeize(struct Exponential.Exp underwaterAssetPrice, struct Exponential.Exp collateralPrice, uint256 closeBorrowAmount_TargetUnderwaterAsset)](#calculateamountseize)
- [borrow(address asset, uint256 amount)](#borrow)

###

Do not pay directly into MoneyMarket, please use `supply`.

```js
function () public payable
```

**Arguments**

| Name | Type | Description |
| ---- | ---- | ----------- |


### min

Simple function to calculate min between two numbers.

```js
function min(uint256 a, uint256 b) internal pure
returns(uint256)
```

**Arguments**

| Name | Type    | Description |
| ---- | ------- | ----------- |
| a    | uint256 |             |
| b    | uint256 |             |

### getBlockNumber

Function to simply retrieve block number
This exists mainly for inheriting test contracts to stub this result.

```js
function getBlockNumber() internal view
returns(uint256)
```

**Arguments**

| Name | Type | Description |
| ---- | ---- | ----------- |


### addCollateralMarket

Adds a given asset to the list of collateral markets. This operation is impossible to reverse.
Note: this will not add the asset if it already exists.

```js
function addCollateralMarket(address asset) internal nonpayable
```

**Arguments**

| Name  | Type    | Description |
| ----- | ------- | ----------- |
| asset | address |             |

### getCollateralMarketsLength

return the number of elements in `collateralMarkets`

```js
function getCollateralMarketsLength() public view
returns(uint256)
```

**Returns**

the length of `collateralMarkets`

**Arguments**

| Name | Type | Description |
| ---- | ---- | ----------- |


### calculateInterestIndex

Calculates a new supply index based on the prevailing interest rates applied over time
This is defined as `we multiply the most recent supply index by (1 + blocks times rate)`

```js
function calculateInterestIndex(uint256 startingInterestIndex, uint256 interestRateMantissa, uint256 blockStart, uint256 blockEnd) internal pure
returns(enum ErrorReporter.Error, uint256)
```

**Arguments**

| Name                  | Type    | Description |
| --------------------- | ------- | ----------- |
| startingInterestIndex | uint256 |             |
| interestRateMantissa  | uint256 |             |
| blockStart            | uint256 |             |
| blockEnd              | uint256 |             |

### calculateBalance

Calculates a new balance based on a previous balance and a pair of interest indices
This is defined as: `The user's last balance checkpoint is multiplied by the currentSupplyIndex value and divided by the user's checkpoint index value` \* TODO: Is there a way to handle this that is less likely to overflow?

```js
function calculateBalance(uint256 startingBalance, uint256 interestIndexStart, uint256 interestIndexEnd) internal pure
returns(enum ErrorReporter.Error, uint256)
```

**Arguments**

| Name               | Type    | Description |
| ------------------ | ------- | ----------- |
| startingBalance    | uint256 |             |
| interestIndexStart | uint256 |             |
| interestIndexEnd   | uint256 |             |

### getPriceForAssetAmount

Gets the price for the amount specified of the given asset.

```js
function getPriceForAssetAmount(address asset, uint256 assetAmount) internal view
returns(enum ErrorReporter.Error, struct Exponential.Exp)
```

**Arguments**

| Name        | Type    | Description |
| ----------- | ------- | ----------- |
| asset       | address |             |
| assetAmount | uint256 |             |

### getPriceForAssetAmountMulCollatRatio

Gets the price for the amount specified of the given asset multiplied by the current
collateral ratio (i.e., assetAmountWei _ collateralRatio _ oraclePrice = totalValueInEth).
We will group this as `(oraclePrice * collateralRatio) * assetAmountWei`

```js
function getPriceForAssetAmountMulCollatRatio(address asset, uint256 assetAmount) internal view
returns(enum ErrorReporter.Error, struct Exponential.Exp)
```

**Arguments**

| Name        | Type    | Description |
| ----------- | ------- | ----------- |
| asset       | address |             |
| assetAmount | uint256 |             |

### calculateBorrowAmountWithFee

Calculates the origination fee added to a given borrowAmount
This is simply `(1 + originationFee) * borrowAmount` \* TODO: Track at what magnitude this fee rounds down to zero?

```js
function calculateBorrowAmountWithFee(uint256 borrowAmount) internal view
returns(enum ErrorReporter.Error, uint256)
```

**Arguments**

| Name         | Type    | Description |
| ------------ | ------- | ----------- |
| borrowAmount | uint256 |             |

### fetchAssetPrice

fetches the price of asset from the PriceOracle and converts it to Exp

```js
function fetchAssetPrice(address asset) internal view
returns(enum ErrorReporter.Error, struct Exponential.Exp)
```

**Arguments**

| Name  | Type    | Description                         |
| ----- | ------- | ----------------------------------- |
| asset | address | asset whose price should be fetched |

### assetPrices

Reads scaled price of specified asset from the price oracle

```js
function assetPrices(address asset) public view
returns(uint256)
```

**Returns**

0 on an error or missing price, the price scaled by 1e18 otherwise

**Arguments**

| Name  | Type    | Description                           |
| ----- | ------- | ------------------------------------- |
| asset | address | Asset whose price should be retrieved |

### getAssetAmountForValue

Gets the amount of the specified asset given the specified Eth value
ethValue / oraclePrice = assetAmountWei
If there's no oraclePrice, this returns (Error.DIVISION_BY_ZERO, 0)

```js
function getAssetAmountForValue(address asset, struct Exponential.Exp ethValue) internal view
returns(enum ErrorReporter.Error, uint256)
```

**Arguments**

| Name     | Type                   | Description |
| -------- | ---------------------- | ----------- |
| asset    | address                |             |
| ethValue | struct Exponential.Exp |             |

### \_setPendingAdmin

Begins transfer of admin rights. The newPendingAdmin must call `_acceptAdmin` to finalize the transfer.

```js
function _setPendingAdmin(address newPendingAdmin) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details) \* TODO: Should we add a second arg to verify, like a checksum of `newAdmin` address?

**Arguments**

| Name            | Type    | Description        |
| --------------- | ------- | ------------------ |
| newPendingAdmin | address | New pending admin. |

### \_acceptAdmin

Accepts transfer of admin rights. msg.sender must be pendingAdmin

```js
function _acceptAdmin() public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name | Type | Description |
| ---- | ---- | ----------- |


### \_setOracle

Set new oracle, who can set asset prices

```js
function _setOracle(address newOracle) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name      | Type    | Description        |
| --------- | ------- | ------------------ |
| newOracle | address | New oracle address |

### \_setPaused

set `paused` to the specified state

```js
function _setPaused(bool requestedState) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name           | Type | Description                 |
| -------------- | ---- | --------------------------- |
| requestedState | bool | value to assign to `paused` |

### getAccountLiquidity

returns the liquidity for given account.
a positive result indicates ability to borrow, whereas
a negative result indicates a shortfall which may be liquidated

```js
function getAccountLiquidity(address account) public view
returns(int256)
```

**Returns**

signed integer in terms of eth-wei (negative indicates a shortfall)

**Arguments**

| Name    | Type    | Description            |
| ------- | ------- | ---------------------- |
| account | address | the account to examine |

### getSupplyBalance

return supply balance with any accumulated interest for `asset` belonging to `account`

```js
function getSupplyBalance(address account, address asset) public view
returns(uint256)
```

**Returns**

uint supply balance on success, throws on failed assertion otherwise

**Arguments**

| Name    | Type    | Description                                                                    |
| ------- | ------- | ------------------------------------------------------------------------------ |
| account | address | the account to examine                                                         |
| asset   | address | the market asset whose supply balance belonging to `account` should be checked |

### getBorrowBalance

return borrow balance with any accumulated interest for `asset` belonging to `account`

```js
function getBorrowBalance(address account, address asset) public view
returns(uint256)
```

**Returns**

uint borrow balance on success, throws on failed assertion otherwise

**Arguments**

| Name    | Type    | Description                                                                    |
| ------- | ------- | ------------------------------------------------------------------------------ |
| account | address | the account to examine                                                         |
| asset   | address | the market asset whose borrow balance belonging to `account` should be checked |

### \_supportMarket

Supports a given market (asset) for use

```js
function _supportMarket(address asset, InterestRateModel interestRateModel) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name              | Type              | Description                                              |
| ----------------- | ----------------- | -------------------------------------------------------- |
| asset             | address           | Asset to support; MUST already have a non-zero price set |
| interestRateModel | InterestRateModel | InterestRateModel to use for the asset                   |

### \_suspendMarket

Suspends a given _supported_ market (asset) from use.
Assets in this state do count for collateral, but users may only withdraw, payBorrow,
and liquidate the asset. The liquidate function no longer checks collateralization.

```js
function _suspendMarket(address asset) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name  | Type    | Description      |
| ----- | ------- | ---------------- |
| asset | address | Asset to suspend |

### \_setRiskParameters

Sets the risk parameters: collateral ratio and liquidation discount

```js
function _setRiskParameters(uint256 collateralRatioMantissa, uint256 liquidationDiscountMantissa) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name                        | Type    | Description                                                                                                                                 |
| --------------------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| collateralRatioMantissa     | uint256 | rational collateral ratio, scaled by 1e18. The de-scaled value must be >= 1.1                                                               |
| liquidationDiscountMantissa | uint256 | rational liquidation discount, scaled by 1e18. The de-scaled value must be <= 0.1 and must be less than (descaled collateral ratio minus 1) |

### \_setOriginationFee

Sets the origination fee (which is a multiplier on new borrows)

```js
function _setOriginationFee(uint256 originationFeeMantissa) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name                   | Type    | Description                                                                   |
| ---------------------- | ------- | ----------------------------------------------------------------------------- |
| originationFeeMantissa | uint256 | rational collateral ratio, scaled by 1e18. The de-scaled value must be >= 1.1 |

### \_setMarketInterestRateModel

Sets the interest rate model for a given market

```js
function _setMarketInterestRateModel(address asset, InterestRateModel interestRateModel) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name              | Type              | Description      |
| ----------------- | ----------------- | ---------------- |
| asset             | address           | Asset to support |
| interestRateModel | InterestRateModel |                  |

### \_withdrawEquity

withdraws `amount` of `asset` from equity for asset, as long as `amount` <= equity. Equity= cash - (supply + borrows)

```js
function _withdrawEquity(address asset, uint256 amount) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name   | Type    | Description                                                    |
| ------ | ------- | -------------------------------------------------------------- |
| asset  | address | asset whose equity should be withdrawn                         |
| amount | uint256 | amount of equity to withdraw; must not exceed equity available |

### supply

supply `amount` of `asset` (which must be supported) to `msg.sender` in the protocol

```js
function supply(address asset, uint256 amount) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name   | Type    | Description                |
| ------ | ------- | -------------------------- |
| asset  | address | The market asset to supply |
| amount | uint256 | The amount to supply       |

### withdraw

withdraw `amount` of `asset` from sender's account to sender's address

```js
function withdraw(address asset, uint256 requestedAmount) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name            | Type    | Description                            |
| --------------- | ------- | -------------------------------------- |
| asset           | address | The market asset to withdraw           |
| requestedAmount | uint256 | The amount to withdraw (or -1 for max) |

### calculateAccountLiquidity

Gets the user's account liquidity and account shortfall balances. This includes
any accumulated interest thus far but does NOT actually update anything in
storage, it simply calculates the account liquidity and shortfall with liquidity being
returned as the first Exp, ie (Error, accountLiquidity, accountShortfall).

```js
function calculateAccountLiquidity(address userAddress) internal view
returns(enum ErrorReporter.Error, struct Exponential.Exp, struct Exponential.Exp)
```

**Arguments**

| Name        | Type    | Description |
| ----------- | ------- | ----------- |
| userAddress | address |             |

### calculateAccountValuesInternal

Gets the ETH values of the user's accumulated supply and borrow balances, scaled by 10e18.
This includes any accumulated interest thus far but does NOT actually update anything in
storage

```js
function calculateAccountValuesInternal(address userAddress) internal view
returns(enum ErrorReporter.Error, uint256, uint256)
```

**Returns**

(error code, sum ETH value of supplies scaled by 10e18, sum ETH value of borrows scaled by 10e18)
TODO: Possibly should add a Min(500, collateralMarkets.length) for extra safety
TODO: To help save gas we could think about using the current Market.interestIndex
accumulate interest rather than calculating it

**Arguments**

| Name        | Type    | Description                     |
| ----------- | ------- | ------------------------------- |
| userAddress | address | account for which to sum values |

### calculateAccountValues

Gets the ETH values of the user's accumulated supply and borrow balances, scaled by 10e18.
This includes any accumulated interest thus far but does NOT actually update anything in
storage

```js
function calculateAccountValues(address userAddress) public view
returns(uint256, uint256, uint256)
```

**Returns**

(uint 0=success; otherwise a failure (see ErrorReporter.sol for details),
sum ETH value of supplies scaled by 10e18,
sum ETH value of borrows scaled by 10e18)

**Arguments**

| Name        | Type    | Description                     |
| ----------- | ------- | ------------------------------- |
| userAddress | address | account for which to sum values |

### repayBorrow

Users repay borrowed assets from their own address to the protocol.

```js
function repayBorrow(address asset, uint256 amount) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name   | Type    | Description                         |
| ------ | ------- | ----------------------------------- |
| asset  | address | The market asset to repay           |
| amount | uint256 | The amount to repay (or -1 for max) |

### liquidateBorrow

users repay all or some of an underwater borrow and receive collateral

```js
function liquidateBorrow(address targetAccount, address assetBorrow, address assetCollateral, uint256 requestedAmountClose) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name                 | Type    | Description                                        |
| -------------------- | ------- | -------------------------------------------------- |
| targetAccount        | address | The account whose borrow should be liquidated      |
| assetBorrow          | address | The market asset to repay                          |
| assetCollateral      | address | The borrower's market asset to receive in exchange |
| requestedAmountClose | uint256 | The amount to repay (or -1 for max)                |

### emitLiquidationEvent

this function exists to avoid error `CompilerError: Stack too deep, try removing local variables.` in `liquidateBorrow`

```js
function emitLiquidationEvent(struct MoneyMarket.LiquidateLocalVars localResults) internal nonpayable
```

**Arguments**

| Name         | Type                                  | Description |
| ------------ | ------------------------------------- | ----------- |
| localResults | struct MoneyMarket.LiquidateLocalVars |             |

### calculateDiscountedRepayToEvenAmount

This should ONLY be called if market is supported. It returns shortfall / [Oracle price for the borrow * (collateralRatio - liquidationDiscount - 1)]
If the market isn't supported, we support liquidation of asset regardless of shortfall because we want borrows of the unsupported asset to be closed.
Note that if collateralRatio = liquidationDiscount + 1, then the denominator will be zero and the function will fail with DIVISION_BY_ZERO.

```js
function calculateDiscountedRepayToEvenAmount(address targetAccount, struct Exponential.Exp underwaterAssetPrice) internal view
returns(enum ErrorReporter.Error, uint256)
```

**Arguments**

| Name                 | Type                   | Description |
| -------------------- | ---------------------- | ----------- |
| targetAccount        | address                |             |
| underwaterAssetPrice | struct Exponential.Exp |             |

### calculateDiscountedBorrowDenominatedCollateral

discountedBorrowDenominatedCollateral = [supplyCurrent / (1 + liquidationDiscount)] \* (Oracle price for the collateral / Oracle price for the borrow)

```js
function calculateDiscountedBorrowDenominatedCollateral(struct Exponential.Exp underwaterAssetPrice, struct Exponential.Exp collateralPrice, uint256 supplyCurrent_TargetCollateralAsset) internal view
returns(enum ErrorReporter.Error, uint256)
```

**Arguments**

| Name                                | Type                   | Description |
| ----------------------------------- | ---------------------- | ----------- |
| underwaterAssetPrice                | struct Exponential.Exp |             |
| collateralPrice                     | struct Exponential.Exp |             |
| supplyCurrent_TargetCollateralAsset | uint256                |             |

### calculateAmountSeize

returns closeBorrowAmount*TargetUnderwaterAsset * (1+liquidationDiscount) \_ priceBorrow/priceCollateral

```js
function calculateAmountSeize(struct Exponential.Exp underwaterAssetPrice, struct Exponential.Exp collateralPrice, uint256 closeBorrowAmount_TargetUnderwaterAsset) internal view
returns(enum ErrorReporter.Error, uint256)
```

**Arguments**

| Name                                    | Type                   | Description |
| --------------------------------------- | ---------------------- | ----------- |
| underwaterAssetPrice                    | struct Exponential.Exp |             |
| collateralPrice                         | struct Exponential.Exp |             |
| closeBorrowAmount_TargetUnderwaterAsset | uint256                |             |

### borrow

Users borrow assets from the protocol to their own address

```js
function borrow(address asset, uint256 amount) public nonpayable
returns(uint256)
```

**Returns**

uint 0=success, otherwise a failure (see ErrorReporter.sol for details)

**Arguments**

| Name   | Type    | Description                |
| ------ | ------- | -------------------------- |
| asset  | address | The market asset to borrow |
| amount | uint256 | The amount to borrow       |

## Contracts

- [CarefulMath](CarefulMath.md)
- [EIP20Interface](EIP20Interface.md)
- [EIP20NonStandardInterface](EIP20NonStandardInterface.md)
- [ErrorReporter](ErrorReporter.md)
- [ExchangeRateModel](ExchangeRateModel.md)
- [Exponential](Exponential.md)
- [InterestRateModel](InterestRateModel.md)
- [LiquidationChecker](LiquidationChecker.md)
- [Liquidator](Liquidator.md)
- [Migrations](Migrations.md)
- [MoneyMarket](MoneyMarket.md)
- [PriceOracle](PriceOracle.md)
- [PriceOracleInterface](PriceOracleInterface.md)
- [PriceOracleProxy](PriceOracleProxy.md)
- [SafeToken](SafeToken.md)
